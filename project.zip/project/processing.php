<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Blagounette</title>
</head>
<body>
    <section>
        <?php
        session_start();
        $_SESSION["id"]=0;
        // Check if form data is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Retrieve form data
            $name = isset($_POST["name"]) ? $_POST["name"] : "";
            $op1  = isset($_POST["op1"]) ? $_POST["op1"] : "";
            $op2  = isset($_POST["op2"]) ? $_POST["op2"] : "";
            $op3  = isset($_POST["op3"]) ? $_POST["op3"] : "";
            $hundred  = isset($_POST["hundred"]) ? $_POST["hundred"] : "";
            $ten  = isset($_POST["ten"]) ? $_POST["ten"] : "";
            $unit = isset($_POST["unit"]) ? $_POST["unit"] : "";
            echo $op1.$op2.$op3.$hundred.$ten.$unit;
            if ($name === '') 
            {
                echo "<h1>Donot forget to write your first name</h1>";
                header("Location: index.php?error=do not forget to ");
                exit();
            }
            $count=0;
            if($op1=='13')
            {
                $count=$count+1;
            }
            if($op2=='18')
            {
                $count=$count+1;
            }
            if($op3=='20')
            {
                $count=$count+1;
            }
            if($hundred=='3')
            {
                $count=$count+1;
            }
            if($ten=='7')
            {
                $count=$count+1;
            }
            if($unit=='9')
            {
                $count=$count+1;
            }
            echo $count;
            if($count<6)
            {
                header("Location: index.php?error=low_score&count=".$count);
                
            }
            else{
            $mysqli = new mysqli("localhost:3306", "root", "Naren@03561", "ce1");
            $stmt = $mysqli->prepare("INSERT INTO eleve (id,name) VALUES (?,?)");
            $_SESSION["id"]=$_SESSION["id"]+1;
            $stmt->bind_param('is',$_SESSION["id"],$name);
            $stmt->execute();
            $stmt->close();
        
            // Close the database connection
            $mysqli->close();
            header("Location: bravo.php");
            }
            
        } else {
            // Handle invalid request
            echo "Invalid request";
            exit();
        }
        ?>
    </section>
</body>
</html>
