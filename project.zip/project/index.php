<!DOCTYPE html>
<head>
<link rel="stylesheet" href="style.css">
<title>CE1 math assessments</title>
</head>
<body>
 <section class="quiz">
 <?php
// Check for error parameter
if (isset($_GET['error']) && $_GET['error'] === 'low_score') {
    if($_GET['count']=='1')
    {
        echo '<p style="color: blue;">Your score is 1 ;Please try again.</p>';
    }
    if($_GET['count']=='2')
    {
        echo '<p style="color: blue;">Your score is 2 ;Please try again.</p>';
    }
    if($_GET['count']=='3')
    {
        echo '<p style="color: blue;">Your score is 3 ;Please try again.</p>';
    }
    if($_GET['count']=='4')
    {
        echo '<p style="color: blue;">Your score is 4 ;Please try again.</p>';
    }
    if($_GET['count']=='5')
    {
        echo '<p style="color: blue;">Your score is 1 ;Please try again.</p>';
    }
}
?>
 <form action="processing.php" method="POST">

 <label for="name">First name: </label><br>
 <input type="text" id="name" name="name" ><br><br>
 <fieldset>
 Mental arithmetic: </br>
 10 + 3 = <input class="operation" type="text" id="op1" name="op1"><br>
 9 + 9 = <input class="operation" type="text" id="op2" name="op2"><br>
 7 + 13 = <input class="operation" type="text" id="op3" name="op3"><br> 
 </fieldset>
 <br><br>
 <fieldset>
 379 is a number with
 <select class="operation" name="hundred">
 <option value=""> -</option>
 <option value="1"> 1</option>
 <option value="2"> 2</option>
 <option value="3"> 3</option>
 <option value="4"> 4</option>
 <option value="5"> 5</option>
 <option value="6"> 6</option>
 <option value="7"> 7</option>
 <option value="8"> 8</option>
 <option value="9"> 9</option>
 </select> hundreds +
 <select class="operation" name="ten">
 <option value=""> -</option>
 <option value="1"> 1</option>
 <option value="2"> 2</option>
 <option value="3"> 3</option>
 <option value="4"> 4</option>
 <option value="5"> 5</option>
 <option value="6"> 6</option>
 <option value="7"> 7</option>
 <option value="8"> 8</option>
 <option value="9"> 9</option>
 </select> tens +
 <select class="operation" name="unit">
 <option value=""> -</option>
 <option value="1"> 1</option>
 <option value="2"> 2</option>
 <option value="3"> 3</option>
 <option value="4"> 4</option>
 <option value="5"> 5</option>
 <option value="6"> 6</option>
 <option value="7"> 7</option>
 <option value="8"> 8</option>
 <option value="9"> 9</option>
 </select> units <br><br>

 </fieldset>
 <br><br>
 <input type="submit" value="Check" onclick="check()">
 <input type="reset" value="delete answers">
 </form>
 </section>
 <script>
function isInteger(value) {
    return /^\d+$/.test(value);
  }

  // Function to display warning message
  function displayWarning(inputId) {
    alert("Warning, you must enter a digit");
    document.getElementById(inputId).style.backgroundColor = 'red';
    //document.getElementById(inputId).focus();
  }

  // Function to validate input on leaving the field
  function validateInput(inputId) {
    const inputValue = document.getElementById(inputId).value;
    if (!isInteger(inputValue)) {
      displayWarning(inputId);
      return false;
    } else {
      document.getElementById(inputId).style.backgroundColor = ''; // Reset background color
      return true;
    }
  }

  function check() {
    alert('Please check before submit');
    // Validate input fields
    const isOp1Valid = validateInput('op1');
    const isOp2Valid = validateInput('op2');
    const isOp3Valid = validateInput('op3');

    // You can add more validation for other fields if needed

    // Submit the form only if all validations pass
    if (isOp1Valid && isOp2Valid && isOp3Valid) {
      document.forms[0].submit(); // Submit the form
    }
  }
</script>
</body>
</html>